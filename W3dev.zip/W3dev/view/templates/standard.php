<?php 
$this->load->view('include/header.php');

$this->load->view($main_content);

//$this->load->view('include/footer.php');

?>