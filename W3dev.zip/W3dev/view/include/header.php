<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>TO DO</title>
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/styles.css" type="text/css"/>
	<script src="<?php echo base_url(); ?>js/jquery-1.9.1.min.js"></script>

</head>
<html>	