
<div id="container">
	<h1>MY TO DO App</h1>

	<h2> Add your task below</h2>
	<?php echo form_open('create-task'); ?>
	  <?php echo form_label('Task','task').' '.form_input('task'); ?>
	  <?php echo form_submit('submit','Add task'); ?>
	  <?php echo form_close(); ?>
	</div>

